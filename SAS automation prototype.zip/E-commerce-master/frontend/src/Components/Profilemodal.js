import React from 'react'
import "../Styles/Profilemodal.css"

function Profilemodal() {
    return (
        <div className="profilemodal"> 
            <a>Sign in</a>
            <hr></hr>
            <a>Register</a>
            <hr></hr>
            <a>Sign out</a>            
        </div>
    )
}
export default Profilemodal
